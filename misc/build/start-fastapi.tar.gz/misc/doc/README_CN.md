# start-fastapi

2021版，简易Web后端开发框架，基于[FastAPI](https://github.com/tiangolo/fastapi)

定位是快速实现效率工具/轻量级后端，比如IM机器人（微信），

整个框架在fastapi基础上梳理了目录结构、配置等容易踩坑的内容，梳理了一些约定，这样业务就能基本专心写crud了

有兴趣的同学，也可以使用[2020版](https://github.com/utmhikari/start-fastapi/tree/v2020_final)

## 环境需求

- python 3.6+ (类型检查用)
- idea/pycharm (推荐)
- `pip3 install -r ./requirements.txt` (recommended using venv)
